export const experiences = [
  {
    id: 1,
    title: "Birth of Light",
    icon: "Sunrise",
    copy: "Darkness first. Then a single flame finds you, the way it found a child in Gokul, long ago.",
  },
  {
    id: 2,
    title: "Gokul Courtyard",
    icon: "Home",
    copy: "Lanterns. Laughter caught in stone walls. The warmth of a home you've never visited but somehow remember.",
  },
  {
    id: 3,
    title: "Vrindavan Forest",
    icon: "Trees",
    copy: "Trees lean in close, lit from within. Every path forward feels like it has chosen you, not the other way round.",
  },
  {
    id: 4,
    title: "Call of the Flute",
    icon: "Music2",
    copy: "A single note, carried on wind that shouldn't exist indoors. You follow it before you decide to.",
  },
  {
    id: 5,
    title: "Radha Pavilion",
    icon: "Flower2",
    copy: "Stillness shaped like longing. A space built entirely around the ache of waiting for someone you love.",
  },
  {
    id: 6,
    title: "Cosmic Krishna",
    icon: "Sparkles",
    copy: "The form expands beyond the body. Galaxies move where a face should be. You are looking at infinity, briefly.",
  },
  {
    id: 7,
    title: "Shunya Mandala",
    icon: "CircleDot",
    copy: "A circle that means nothing and everything. Shunya — the zero before the dance, the silence before the sound.",
  },
  {
    id: 8,
    title: "Ras Awakens",
    icon: "Flame",
    copy: "The first beat returns to your chest before you hear it. Your feet remember a rhythm older than memory.",
  },
  {
    id: 9,
    title: "Maharaas",
    icon: "Stars",
    copy: "Under an open sky, the circle finally completes. Every step you took tonight was leading you here.",
  },
];
