import { useRef, useState } from "react";
import NavBar from "./components/NavBar";
import Hero from "./components/Hero";
import Story from "./components/Story";
import NineExperiences from "./components/NineExperiences";
import DigitalPass from "./components/DigitalPass";
import Inclusions from "./components/Inclusions";
import Venue from "./components/Venue";
import LimitedPasses from "./components/LimitedPasses";
import InnerCircle from "./components/InnerCircle";
import BookingForm from "./components/BookingForm";
import Footer from "./components/Footer";

function App() {
  const bookingRef = useRef(null);
  const [requestedPassType, setRequestedPassType] = useState(null);

  const scrollToBooking = (passType) => {
    if (passType) setRequestedPassType(passType);
    bookingRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="bg-void-deep">
      <NavBar onReserve={() => scrollToBooking()} />
      <Hero onReserve={() => scrollToBooking()} />
      <Story />
      <NineExperiences />
      <DigitalPass />
      <Inclusions />
      <Venue />
      <LimitedPasses onReserve={() => scrollToBooking()} />
      <InnerCircle onReserve={scrollToBooking} />
      <BookingForm forwardedRef={bookingRef} initialPassType={requestedPassType} />
      <Footer />
    </div>
  );
}

export default App;
