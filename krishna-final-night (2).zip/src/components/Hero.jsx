import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowRight, MapPin, Moon } from "lucide-react";
import PeacockFeather from "./PeacockFeather";
import ParticleField from "./ParticleField";

const EVENT_DATE = new Date("2026-10-21T18:30:00+05:30").getTime();

function useCountdown(target) {
  const [time, setTime] = useState({ d: 0, h: 0, m: 0, s: 0 });

  useEffect(() => {
    const tick = () => {
      const diff = Math.max(target - Date.now(), 0);
      const d = Math.floor(diff / 86400000);
      const h = Math.floor((diff % 86400000) / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setTime({ d, h, m, s });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [target]);

  return time;
}

function TimeUnit({ value, label }) {
  return (
    <div className="flex flex-col items-center gap-1.5 min-w-[58px] sm:min-w-[68px]">
      <div className="glass rounded-xl px-3 py-2.5 sm:px-4 sm:py-3 w-full text-center">
        <span className="font-display text-2xl sm:text-3xl text-moonlight tabular-nums">
          {String(value).padStart(2, "0")}
        </span>
      </div>
      <span className="eyebrow text-moonlight-dim text-[0.58rem] sm:text-[0.62rem]">{label}</span>
    </div>
  );
}

export default function Hero({ onReserve }) {
  const { d, h, m, s } = useCountdown(EVENT_DATE);

  return (
    <section className="relative min-h-[100vh] flex flex-col items-center justify-center overflow-hidden px-6">
      {/* Backdrop layers */}
      <div className="absolute inset-0 bg-gradient-to-b from-void-deep via-void to-void-raised" />
      <div className="absolute inset-0 dot-grid opacity-60" />
      <div className="absolute top-[-10%] left-1/2 -translate-x-1/2 w-[700px] h-[700px] glow-gold rounded-full blur-3xl opacity-50" />
      <div className="absolute bottom-[-15%] right-[-10%] w-[500px] h-[500px] glow-peacock rounded-full blur-3xl opacity-40" />
      <ParticleField count={50} />

      {/* Floating peacock feathers */}
      <PeacockFeather
        className="hidden sm:block absolute top-[14%] left-[8%] w-12 sm:w-16 text-gold-bright float-slow"
        opacity={0.35}
      />
      <PeacockFeather
        className="hidden sm:block absolute bottom-[18%] right-[10%] w-14 sm:w-20 text-peacock-bright float-slower"
        opacity={0.3}
      />
      <PeacockFeather
        className="absolute top-[8%] right-[6%] w-8 sm:w-12 text-moonlight-silver float-slow"
        opacity={0.25}
      />

      {/* Content */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-10 flex flex-col items-center text-center max-w-3xl mx-auto pt-20"
      >
        <div className="flex items-center gap-3 mb-7 text-moonlight-dim">
          <Moon size={14} strokeWidth={1.3} />
          <span className="eyebrow">Invite Only · Last Night of Navratri</span>
          <Moon size={14} strokeWidth={1.3} />
        </div>

        <h1 className="font-display font-light text-[2.6rem] leading-[1.05] sm:text-6xl md:text-7xl lg:text-[5.5rem] tracking-tight text-moonlight">
          KRISHNA
          <span className="block text-foil italic font-normal">The Final Night</span>
        </h1>

        <p className="mt-7 font-display text-lg sm:text-xl md:text-2xl text-moonlight-silver italic max-w-xl">
          Not a Garba. A journey into Krishna's world.
        </p>

        <p className="mt-3 text-sm sm:text-base text-moonlight-dim font-light max-w-md">
          A 9-Hour Immersive Journey Ending in Maharaas
        </p>

        {/* Countdown */}
        <div className="flex items-center gap-2.5 sm:gap-4 mt-10">
          <TimeUnit value={d} label="Days" />
          <TimeUnit value={h} label="Hours" />
          <TimeUnit value={m} label="Mins" />
          <TimeUnit value={s} label="Secs" />
        </div>

        {/* CTA */}
        <motion.button
          onClick={onReserve}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="group mt-11 inline-flex items-center gap-2.5 bg-gradient-to-r from-gold-dim via-gold-bright to-gold-dim text-void-deep font-body font-medium px-8 py-4 rounded-full text-sm sm:text-base shadow-[0_0_40px_rgba(217,189,126,0.35)] transition-shadow hover:shadow-[0_0_60px_rgba(217,189,126,0.5)]"
        >
          Reserve Your Journey Pass — ₹5,000
          <ArrowRight size={17} className="transition-transform group-hover:translate-x-1" />
        </motion.button>

        <div className="flex items-center gap-2 mt-7 text-moonlight-dim">
          <MapPin size={13} strokeWidth={1.4} />
          <span className="text-xs sm:text-sm tracking-wide font-light">
            Secret Farm Location · Ahmedabad · Last Night of Navratri
          </span>
        </div>
      </motion.div>

      {/* Scroll cue */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-moonlight-dim"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
      >
        <span className="eyebrow text-[0.58rem]">Begin the Descent</span>
        <span className="w-px h-8 bg-gradient-to-b from-moonlight-dim to-transparent" />
      </motion.div>
    </section>
  );
}
