import { motion } from "framer-motion";
import { Crown, Sofa, Zap, Gem, UtensilsCrossed, ArrowRight } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";
import PeacockFeather from "./PeacockFeather";

const perks = [
  { icon: Sofa, label: "Private lounge, away from the main circle" },
  { icon: Zap, label: "Fast-track entry — skip the gate queue entirely" },
  { icon: Crown, label: "Reserved viewing zone at the Maharaas" },
  { icon: Gem, label: "A limited Krishna artifact, yours to keep" },
  { icon: UtensilsCrossed, label: "Creator dinner — an intimate table with the makers of the night" },
];

export default function InnerCircle({ onReserve }) {
  return (
    <section className="relative py-28 sm:py-32 px-6 bg-void overflow-hidden">
      <div className="absolute inset-0 dot-grid opacity-20" />
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] glow-gold rounded-full blur-3xl opacity-30" />
      <PeacockFeather className="hidden lg:block absolute top-[12%] right-[10%] w-16 text-gold-bright float-slow" opacity={0.18} />

      <div className="relative z-10 max-w-4xl mx-auto">
        <Reveal className="text-center mb-14">
          <Eyebrow color="gold">For the Few Within the Few</Eyebrow>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="relative rounded-[32px] glass-strong overflow-hidden p-10 sm:p-14">
            <div className="absolute inset-0 bg-gradient-to-br from-gold-dim/15 via-transparent to-peacock-deep/30" />
            <div className="absolute -top-20 -right-20 w-72 h-72 glow-gold rounded-full blur-3xl opacity-40" />

            <div className="relative z-10 text-center">
              <Crown size={28} strokeWidth={1.2} className="text-gold-bright mx-auto mb-5" />
              <h2 className="font-display font-light text-3xl sm:text-4xl text-moonlight">
                Inner Circle Pass
              </h2>
              <p className="font-display italic text-2xl sm:text-3xl text-gold-bright mt-2">₹11,000</p>

              <div className="hairline my-9 max-w-xs mx-auto" />

              <div className="grid sm:grid-cols-2 gap-5 text-left max-w-xl mx-auto">
                {perks.map((perk) => {
                  const Icon = perk.icon;
                  return (
                    <div key={perk.label} className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-full glass flex items-center justify-center shrink-0 mt-0.5">
                        <Icon size={15} strokeWidth={1.4} className="text-gold-bright" />
                      </div>
                      <span className="text-sm text-moonlight-silver font-light leading-relaxed pt-1.5">
                        {perk.label}
                      </span>
                    </div>
                  );
                })}
              </div>

              <motion.button
                onClick={() => onReserve("Inner Circle")}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="group mt-11 inline-flex items-center gap-2.5 border border-gold-bright/50 text-gold-bright font-body font-medium px-8 py-4 rounded-full text-sm sm:text-base hover:bg-gold-bright/10 transition-colors"
              >
                Upgrade to Inner Circle
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </motion.button>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
