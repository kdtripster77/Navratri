import { DoorOpen, Radio, Film, UtensilsCrossed, Sparkle, Users } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";

const inclusions = [
  {
    icon: DoorOpen,
    title: "All Nine Immersive Zones",
    desc: "Unrestricted passage through every experience, from Birth of Light to Maharaas.",
  },
  {
    icon: Radio,
    title: "Journey Wristband",
    desc: "An RFID-enabled wristband that tracks and unlocks your path through the night.",
  },
  {
    icon: Film,
    title: "AI Krishna Memory Film",
    desc: "A personalised short film of your journey, generated and delivered after the event.",
  },
  {
    icon: UtensilsCrossed,
    title: "Mahaprasad Dinner",
    desc: "A curated dinner experience inspired by Krishna's own table, served under open sky.",
  },
  {
    icon: Sparkle,
    title: "Maharaas Under the Stars",
    desc: "The night's closing circle — live, unscripted, and held beneath an open sky.",
  },
  {
    icon: Users,
    title: "Invite-Only Ras Circle",
    desc: "Continued access to a private community of guests long after the night ends.",
  },
];

export default function Inclusions() {
  return (
    <section className="relative py-28 sm:py-32 px-6 bg-void-raised overflow-hidden">
      <div className="absolute inset-0 dot-grid opacity-25" />

      <div className="relative z-10 max-w-6xl mx-auto">
        <Reveal className="text-center mb-16">
          <Eyebrow color="peacock">What Your Pass Includes</Eyebrow>
          <h2 className="font-display font-light text-3xl sm:text-4xl md:text-5xl text-moonlight mt-6">
            Everything within
            <span className="italic text-gold-bright"> the circle.</span>
          </h2>
        </Reveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {inclusions.map((item, i) => {
            const Icon = item.icon;
            return (
              <Reveal key={item.title} delay={(i % 3) * 0.08}>
                <div className="group relative h-full rounded-2xl glass p-7 sm:p-8 overflow-hidden hover:border-gold-dim/40 transition-colors duration-500">
                  <div className="absolute -top-8 -right-8 w-28 h-28 glow-gold rounded-full blur-2xl opacity-0 group-hover:opacity-60 transition-opacity duration-700" />
                  <div className="relative z-10">
                    <div className="w-12 h-12 rounded-full glass-strong flex items-center justify-center mb-5">
                      <Icon size={20} strokeWidth={1.3} className="text-gold-bright" />
                    </div>
                    <h3 className="font-display text-xl text-moonlight font-light">{item.title}</h3>
                    <p className="mt-2.5 text-sm text-moonlight-dim font-light leading-relaxed">
                      {item.desc}
                    </p>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
