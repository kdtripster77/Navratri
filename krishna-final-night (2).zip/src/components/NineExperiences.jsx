import { useRef } from "react";
import { motion } from "framer-motion";
import * as Icons from "lucide-react";
import { ChevronLeft, ChevronRight, Lock } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";
import { experiences } from "../data/experiences";

function ExperienceCard({ exp, index }) {
  const Icon = Icons[exp.icon] || Icons.Sparkles;

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.7, delay: (index % 4) * 0.08, ease: [0.22, 1, 0.36, 1] }}
      className="relative shrink-0 w-[260px] sm:w-[300px] h-[400px] sm:h-[440px] rounded-3xl glass overflow-hidden snap-center group"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-peacock-deep/40 via-transparent to-gold-dim/10" />
      <div className="absolute -top-10 -right-10 w-40 h-40 glow-gold rounded-full blur-3xl opacity-40 group-hover:opacity-70 transition-opacity duration-700" />

      <div className="relative z-10 h-full flex flex-col justify-between p-7 sm:p-8">
        <div>
          <span className="eyebrow text-moonlight-dim">{String(exp.id).padStart(2, "0")} / 09</span>
          <motion.div
            className="mt-7 w-14 h-14 rounded-full glass-strong flex items-center justify-center"
            whileHover={{ scale: 1.08, rotate: 6 }}
            transition={{ type: "spring", stiffness: 200, damping: 15 }}
          >
            <Icon size={24} strokeWidth={1.2} className="text-gold-bright" />
          </motion.div>
          <h3 className="font-display font-light text-2xl sm:text-[1.7rem] text-moonlight mt-6 leading-snug">
            {exp.title}
          </h3>
          <p className="mt-4 text-[0.9rem] text-moonlight-silver font-light leading-relaxed italic">
            {exp.copy}
          </p>
        </div>

        <div className="flex items-center gap-2 text-gold-dim border-t border-moonlight-silver/10 pt-4">
          <Lock size={12} strokeWidth={1.5} />
          <span className="text-[0.68rem] tracking-wide uppercase font-medium text-gold-bright/80">
            Unlocked by your Krishna Pass
          </span>
        </div>
      </div>
    </motion.div>
  );
}

export default function NineExperiences() {
  const scrollerRef = useRef(null);

  const scrollBy = (dir) => {
    if (scrollerRef.current) {
      scrollerRef.current.scrollBy({ left: dir * 320, behavior: "smooth" });
    }
  };

  return (
    <section className="relative py-28 sm:py-32 bg-void-raised overflow-hidden">
      <div className="absolute inset-0 dot-grid opacity-25" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <Reveal className="text-center">
          <Eyebrow color="gold">The Nine Experiences</Eyebrow>
          <h2 className="font-display font-light text-3xl sm:text-4xl md:text-5xl text-moonlight mt-6">
            A path with <span className="italic text-gold-bright">nine doors.</span>
          </h2>
          <p className="mt-4 text-moonlight-dim font-light text-sm sm:text-base max-w-lg mx-auto">
            Every guest walks the same path. No two will remember it the same way.
          </p>
        </Reveal>
      </div>

      <div className="relative mt-14 group">
        <div
          ref={scrollerRef}
          className="flex gap-5 sm:gap-6 overflow-x-auto no-scrollbar px-6 sm:px-[max(1.5rem,calc((100vw-1280px)/2+1.5rem))] snap-x snap-mandatory pb-4"
        >
          {experiences.map((exp, i) => (
            <ExperienceCard key={exp.id} exp={exp} index={i} />
          ))}
          <div className="shrink-0 w-2 sm:w-4" />
        </div>

        {/* Scroll controls - desktop only */}
        <div className="hidden md:flex absolute -bottom-2 right-6 sm:right-[max(1.5rem,calc((100vw-1280px)/2+1.5rem))] gap-3">
          <button
            onClick={() => scrollBy(-1)}
            aria-label="Scroll experiences left"
            className="w-10 h-10 rounded-full glass flex items-center justify-center text-moonlight-silver hover:text-gold-bright transition-colors"
          >
            <ChevronLeft size={18} />
          </button>
          <button
            onClick={() => scrollBy(1)}
            aria-label="Scroll experiences right"
            className="w-10 h-10 rounded-full glass flex items-center justify-center text-moonlight-silver hover:text-gold-bright transition-colors"
          >
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
    </section>
  );
}
