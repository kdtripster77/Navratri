import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";
import ParticleField from "./ParticleField";

export default function Story() {
  return (
    <section className="relative py-28 sm:py-36 px-6 overflow-hidden bg-void">
      <div className="absolute inset-0 dot-grid opacity-30" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] glow-peacock rounded-full blur-3xl opacity-25" />
      <ParticleField count={20} />

      <div className="relative z-10 max-w-3xl mx-auto text-center">
        <Reveal>
          <Eyebrow color="peacock">The Journey</Eyebrow>
        </Reveal>

        <Reveal delay={0.1}>
          <h2 className="font-display font-light text-3xl sm:text-4xl md:text-5xl text-moonlight mt-6 leading-tight">
            Before the dance begins,
            <span className="block italic text-gold-bright mt-1">you must arrive.</span>
          </h2>
        </Reveal>

        <Reveal delay={0.2}>
          <p className="mt-9 text-base sm:text-lg text-moonlight-silver font-light leading-relaxed max-w-2xl mx-auto">
            For nine hours, you will walk through a world built for one night only —
            light before form, forest before clearing, a flute calling from somewhere
            you cannot see. Radha's silence. A mandala that turns like the sky turns.
            And then, the stillness every journey needs before it can become joy.
          </p>
        </Reveal>

        <Reveal delay={0.3}>
          <p className="mt-6 text-base sm:text-lg text-moonlight-silver font-light leading-relaxed max-w-2xl mx-auto">
            Only after the silence does the circle open. Only after the journey
            does the Ras begin. This is not a Garba you attend.
            <span className="text-moonlight italic"> It is a night you walk into. </span>
          </p>
        </Reveal>

        <Reveal delay={0.4}>
          <div className="mt-12 flex items-center justify-center gap-3">
            <span className="h-px w-12 bg-gold-dim opacity-50" />
            <span className="font-display italic text-gold-bright text-lg">
              Nine experiences. One night. One circle.
            </span>
            <span className="h-px w-12 bg-gold-dim opacity-50" />
          </div>
        </Reveal>
      </div>
    </section>
  );
}
