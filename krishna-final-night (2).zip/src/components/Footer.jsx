import PeacockFeather from "./PeacockFeather";

export default function Footer() {
  return (
    <footer className="relative bg-void-deep py-14 px-6 border-t border-moonlight-silver/10 overflow-hidden">
      <PeacockFeather className="hidden md:block absolute -top-4 right-10 w-12 text-gold-bright float-slow" opacity={0.15} />
      <div className="relative z-10 max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6 text-center sm:text-left">
        <div>
          <span className="font-display text-lg text-moonlight">
            Krishna<span className="text-gold-bright italic"> · Final Night</span>
          </span>
          <p className="text-xs text-moonlight-dim font-light mt-1.5">
            A 9-Hour Immersive Journey Ending in Maharaas
          </p>
        </div>
        <p className="text-xs text-moonlight-dim font-light">
          Invite-only · Last night of Navratri · Near Ahmedabad
        </p>
      </div>
    </footer>
  );
}
