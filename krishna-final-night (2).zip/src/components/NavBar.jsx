import { useState, useEffect } from "react";
import { motion } from "framer-motion";

export default function NavBar({ onReserve }) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed top-0 inset-x-0 z-40 transition-all duration-500 ${
        scrolled ? "py-3 glass" : "py-5 bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <span className="font-display text-lg tracking-wide text-moonlight">
          Krishna<span className="text-gold-bright italic"> · Final Night</span>
        </span>
        <button
          onClick={onReserve}
          className="hidden sm:inline-flex items-center text-xs sm:text-sm font-medium text-void-deep bg-gold-bright px-5 py-2.5 rounded-full hover:bg-gold-bright/90 transition-colors"
        >
          Reserve Pass
        </button>
      </div>
    </motion.nav>
  );
}
