import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, X, AtSign, ShieldCheck } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";

const initialForm = {
  name: "",
  mobile: "",
  email: "",
  instagram: "",
  city: "",
  passes: 1,
  passType: "Journey Pass",
};

function validate(form) {
  const errors = {};
  if (!form.name.trim()) errors.name = "Enter your full name";
  if (!/^[6-9]\d{9}$/.test(form.mobile.trim())) errors.mobile = "Enter a valid 10-digit mobile number";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) errors.email = "Enter a valid email address";
  if (!form.city.trim()) errors.city = "Enter your city";
  if (!form.passes || form.passes < 1 || form.passes > 10) errors.passes = "Choose between 1 and 10 passes";
  return errors;
}

function Field({ label, error, children }) {
  return (
    <div>
      <label className="block text-[0.68rem] uppercase tracking-widest2 text-moonlight-dim mb-2">
        {label}
      </label>
      {children}
      {error && <p className="text-xs text-red-300 mt-1.5">{error}</p>}
    </div>
  );
}

const inputClass =
  "w-full bg-void-deep/60 border border-moonlight-silver/15 rounded-xl px-4 py-3 text-sm text-moonlight placeholder:text-moonlight-dim/60 focus:border-gold-bright/60 focus:outline-none transition-colors";

export default function BookingForm({ forwardedRef, initialPassType }) {
  const [form, setForm] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  // Sync the pass type when a CTA elsewhere on the page requests a specific tier
  useEffect(() => {
    if (initialPassType) {
      setForm((f) => ({ ...f, passType: initialPassType }));
    }
  }, [initialPassType]);

  const update = (key) => (e) => {
    const value = key === "passes" ? Number(e.target.value) : e.target.value;
    setForm((f) => ({ ...f, [key]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate(form);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setSubmitting(true);
    // Razorpay placeholder — in production this calls the backend to create
    // an order, then opens Razorpay Checkout with the returned order_id.
    setTimeout(() => {
      setSubmitting(false);
      setSuccess(true);
    }, 1100);
  };

  const closeSuccess = () => {
    setSuccess(false);
    setForm(initialForm);
  };

  return (
    <section
      ref={forwardedRef}
      id="booking"
      className="relative py-28 sm:py-36 px-6 bg-void-raised overflow-hidden"
    >
      <div className="absolute inset-0 dot-grid opacity-25" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] glow-peacock rounded-full blur-3xl opacity-25" />

      <div className="relative z-10 max-w-xl mx-auto">
        <Reveal className="text-center mb-12">
          <Eyebrow color="gold">Reserve Your Place</Eyebrow>
          <h2 className="font-display font-light text-3xl sm:text-4xl md:text-5xl text-moonlight mt-6">
            The circle is
            <span className="italic text-gold-bright"> almost closed.</span>
          </h2>
          <p className="mt-4 text-moonlight-dim font-light text-sm">
            Submit your details to reserve your Journey Pass and proceed to payment.
          </p>
        </Reveal>

        <Reveal delay={0.1}>
          <form onSubmit={handleSubmit} className="rounded-3xl glass-strong p-7 sm:p-9 space-y-6">
            <Field label="Full Name" error={errors.name}>
              <input
                type="text"
                value={form.name}
                onChange={update("name")}
                placeholder="As it will appear on your pass"
                className={inputClass}
                autoComplete="name"
              />
            </Field>

            <div className="grid sm:grid-cols-2 gap-6">
              <Field label="Mobile Number" error={errors.mobile}>
                <input
                  type="tel"
                  value={form.mobile}
                  onChange={update("mobile")}
                  placeholder="98765 43210"
                  className={inputClass}
                  autoComplete="tel"
                />
              </Field>
              <Field label="Email" error={errors.email}>
                <input
                  type="email"
                  value={form.email}
                  onChange={update("email")}
                  placeholder="you@email.com"
                  className={inputClass}
                  autoComplete="email"
                />
              </Field>
            </div>

            <div className="grid sm:grid-cols-2 gap-6">
              <Field label="Instagram Handle" error={errors.instagram}>
                <div className="relative">
                  <AtSign size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-moonlight-dim" strokeWidth={1.5} />
                  <input
                    type="text"
                    value={form.instagram}
                    onChange={update("instagram")}
                    placeholder="@yourhandle"
                    className={`${inputClass} pl-10`}
                  />
                </div>
              </Field>
              <Field label="City" error={errors.city}>
                <input
                  type="text"
                  value={form.city}
                  onChange={update("city")}
                  placeholder="Ahmedabad"
                  className={inputClass}
                />
              </Field>
            </div>

            <div className="grid sm:grid-cols-2 gap-6">
              <Field label="Number of Passes" error={errors.passes}>
                <select value={form.passes} onChange={update("passes")} className={inputClass}>
                  {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => (
                    <option key={n} value={n} className="bg-void-raised">
                      {n} {n === 1 ? "Pass" : "Passes"}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Pass Type">
                <select value={form.passType} onChange={update("passType")} className={inputClass}>
                  <option value="Journey Pass" className="bg-void-raised">Journey Pass — ₹5,000</option>
                  <option value="Inner Circle" className="bg-void-raised">Inner Circle — ₹11,000</option>
                </select>
              </Field>
            </div>

            <motion.button
              type="submit"
              disabled={submitting}
              whileHover={{ scale: submitting ? 1 : 1.01 }}
              whileTap={{ scale: submitting ? 1 : 0.98 }}
              className="w-full inline-flex items-center justify-center gap-2.5 bg-gradient-to-r from-gold-dim via-gold-bright to-gold-dim text-void-deep font-body font-medium px-8 py-4 rounded-full text-sm sm:text-base disabled:opacity-70 mt-2"
            >
              {submitting ? (
                <>
                  <span className="w-4 h-4 border-2 border-void-deep/40 border-t-void-deep rounded-full animate-spin" />
                  Processing
                </>
              ) : (
                <>
                  <ShieldCheck size={16} strokeWidth={1.6} />
                  Proceed to Secure Payment
                </>
              )}
            </motion.button>

            <p className="text-center text-[0.7rem] text-moonlight-dim/70 pt-1">
              Payments secured via Razorpay · Passes are non-refundable, non-transferable
            </p>
          </form>
        </Reveal>
      </div>

      {/* Success modal */}
      <AnimatePresence>
        {success && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center px-6 bg-void-deep/80 backdrop-blur-sm"
            onClick={closeSuccess}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-sm w-full rounded-3xl glass-strong p-9 text-center"
            >
              <button
                onClick={closeSuccess}
                aria-label="Close"
                className="absolute top-5 right-5 text-moonlight-dim hover:text-moonlight transition-colors"
              >
                <X size={18} />
              </button>

              <div className="w-14 h-14 rounded-full glass-strong flex items-center justify-center mx-auto mb-6">
                <Check size={24} className="text-gold-bright" strokeWidth={1.6} />
              </div>

              <h3 className="font-display text-2xl text-moonlight font-light">
                Your Krishna Journey Pass is reserved.
              </h3>
              <p className="mt-3 text-sm text-moonlight-silver font-light leading-relaxed">
                You will receive your digital access card shortly.
              </p>

              <button
                onClick={closeSuccess}
                className="mt-8 w-full bg-gradient-to-r from-gold-dim via-gold-bright to-gold-dim text-void-deep font-medium px-6 py-3.5 rounded-full text-sm"
              >
                Done
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
