import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Ticket } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";

const TOTAL_PASSES = 500;
// Static baseline for display purposes; a real backend would supply the live count.
const STARTING_REMAINING = 137;

export default function LimitedPasses({ onReserve }) {
  const [remaining, setRemaining] = useState(STARTING_REMAINING);

  useEffect(() => {
    // Subtle illusion of live movement — ticks down occasionally, never below a floor.
    const interval = setInterval(() => {
      setRemaining((prev) => (prev > 60 ? prev - 1 : prev));
    }, 45000);
    return () => clearInterval(interval);
  }, []);

  const claimedPct = Math.round(((TOTAL_PASSES - remaining) / TOTAL_PASSES) * 100);

  return (
    <section className="relative py-28 sm:py-32 px-6 bg-void-raised overflow-hidden">
      <div className="absolute inset-0 dot-grid opacity-25" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] glow-gold rounded-full blur-3xl opacity-25" />

      <div className="relative z-10 max-w-3xl mx-auto text-center">
        <Reveal>
          <Eyebrow color="gold">Limited Passes</Eyebrow>
          <h2 className="font-display font-light text-3xl sm:text-4xl md:text-5xl text-moonlight mt-6">
            500 passes.
            <span className="italic text-gold-bright"> No more.</span>
          </h2>
          <p className="mt-4 text-moonlight-dim font-light text-sm sm:text-base">
            Curated guest list · ₹5,000 per pass · No on-ground sales
          </p>
        </Reveal>

        <Reveal delay={0.15}>
          <div className="mt-12 rounded-3xl glass-strong p-8 sm:p-10">
            <div className="flex items-center justify-center gap-2.5 text-gold-bright mb-5">
              <Ticket size={18} strokeWidth={1.4} />
              <span className="eyebrow text-[0.62rem]">Passes Remaining</span>
            </div>

            <motion.span
              key={remaining}
              initial={{ opacity: 0.4, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              className="font-display text-5xl sm:text-6xl text-moonlight tabular-nums"
            >
              {remaining}
            </motion.span>
            <span className="block text-moonlight-dim text-sm mt-1.5">
              of {TOTAL_PASSES} total Journey Passes
            </span>

            <div className="mt-7 h-1.5 w-full rounded-full bg-void overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-gold-dim via-gold-bright to-gold-bright"
                initial={{ width: 0 }}
                whileInView={{ width: `${claimedPct}%` }}
                viewport={{ once: true }}
                transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
              />
            </div>
            <span className="block text-moonlight-dim text-xs mt-2.5">
              {claimedPct}% of passes already claimed
            </span>

            <motion.button
              onClick={onReserve}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="mt-9 inline-flex items-center justify-center gap-2.5 bg-gradient-to-r from-gold-dim via-gold-bright to-gold-dim text-void-deep font-body font-medium px-8 py-4 rounded-full text-sm sm:text-base shadow-[0_0_40px_rgba(217,189,126,0.3)] w-full sm:w-auto"
            >
              Apply &amp; Reserve Pass
            </motion.button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
