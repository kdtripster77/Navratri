export default function Eyebrow({ children, color = "gold" }) {
  const colorMap = {
    gold: "text-gold-bright",
    peacock: "text-peacock-bright",
    silver: "text-moonlight-silver",
  };
  return (
    <div className="flex items-center gap-3 justify-center">
      <span className="h-px w-8 bg-current opacity-40" />
      <span className={`eyebrow ${colorMap[color]}`}>{children}</span>
      <span className="h-px w-8 bg-current opacity-40" />
    </div>
  );
}
