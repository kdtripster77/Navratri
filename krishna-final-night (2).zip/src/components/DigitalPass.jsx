import { useState } from "react";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";
import PeacockFeather from "./PeacockFeather";

function QRPlaceholder() {
  // Deterministic pseudo-QR pattern for visual purposes
  const cells = [];
  const seed = [
    1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1,
    1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1,
    1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1,
    0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0,
    1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1,
    1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1,
    0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0,
  ];
  for (let i = 0; i < seed.length; i++) {
    cells.push(seed[i]);
  }
  return (
    <div className="grid grid-cols-12 gap-[2px] w-full h-full p-2">
      {cells.map((on, i) => (
        <div
          key={i}
          className={`aspect-square rounded-[1px] ${on ? "bg-void-deep" : "bg-transparent"}`}
        />
      ))}
    </div>
  );
}

export default function DigitalPass() {
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ x: py * -8, y: px * 10 });
  };

  const resetTilt = () => setTilt({ x: 0, y: 0 });

  return (
    <section className="relative py-28 sm:py-36 px-6 bg-void overflow-hidden">
      <div className="absolute inset-0 dot-grid opacity-20" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[600px] h-[600px] glow-gold rounded-full blur-3xl opacity-30" />
      <PeacockFeather className="hidden lg:block absolute top-[10%] left-[6%] w-20 text-peacock-bright float-slower" opacity={0.2} />
      <PeacockFeather className="hidden lg:block absolute bottom-[8%] right-[8%] w-16 text-gold-bright float-slow" opacity={0.22} />

      <div className="relative z-10 max-w-6xl mx-auto">
        <Reveal className="text-center mb-16">
          <Eyebrow color="gold">Your Credential</Eyebrow>
          <h2 className="font-display font-light text-3xl sm:text-4xl md:text-5xl text-moonlight mt-6">
            Not a ticket.
            <span className="block italic text-gold-bright mt-1">An access card.</span>
          </h2>
        </Reveal>

        <div className="flex flex-col lg:flex-row items-center gap-14 lg:gap-20 justify-center">
          {/* The Card */}
          <Reveal delay={0.1} className="shrink-0">
            <motion.div
              onMouseMove={handleMouseMove}
              onMouseLeave={resetTilt}
              animate={{ rotateX: tilt.x, rotateY: tilt.y }}
              transition={{ type: "spring", stiffness: 120, damping: 14 }}
              style={{ transformStyle: "preserve-3d", perspective: 1000 }}
              className="relative w-[320px] sm:w-[380px] h-[480px] sm:h-[560px] rounded-[28px] glass-strong sheen overflow-hidden shadow-[0_30px_80px_rgba(0,0,0,0.6)]"
            >
              {/* Card backdrop texture */}
              <div className="absolute inset-0 bg-gradient-to-br from-peacock-deep/50 via-void-raised/40 to-gold-dim/15" />
              <div className="absolute inset-0 dot-grid opacity-20" />
              <PeacockFeather className="absolute -bottom-6 -right-8 w-40 text-gold-bright" opacity={0.12} />

              <div className="relative z-10 h-full flex flex-col p-7 sm:p-8">
                {/* Header */}
                <div className="flex items-center justify-between">
                  <span className="eyebrow text-gold-bright text-[0.6rem]">Krishna · The Final Night</span>
                  <Sparkles size={15} className="text-gold-bright" strokeWidth={1.3} />
                </div>

                <div className="hairline my-5" />

                {/* Name */}
                <div>
                  <span className="text-[0.62rem] uppercase tracking-widest2 text-moonlight-dim">
                    Guest
                  </span>
                  <p className="font-display text-2xl sm:text-3xl text-moonlight mt-1">KARNA DESAI</p>
                </div>

                <div className="mt-6">
                  <span className="text-[0.62rem] uppercase tracking-widest2 text-moonlight-dim">
                    Credential
                  </span>
                  <p className="font-display italic text-lg sm:text-xl text-gold-bright mt-1">
                    Krishna Journey Pass
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-5 mt-7">
                  <div>
                    <span className="text-[0.6rem] uppercase tracking-widest2 text-moonlight-dim">Access</span>
                    <p className="text-sm text-moonlight mt-1 font-light">All 9 Experiences</p>
                  </div>
                  <div>
                    <span className="text-[0.6rem] uppercase tracking-widest2 text-moonlight-dim">Pass Value</span>
                    <p className="text-sm text-moonlight mt-1 font-light">₹5,000</p>
                  </div>
                </div>

                {/* QR + footer pinned to bottom */}
                <div className="mt-auto flex items-end justify-between pt-6">
                  <div>
                    <span className="text-[0.6rem] uppercase tracking-widest2 text-moonlight-dim">Journey ID</span>
                    <p className="text-sm text-moonlight mt-1 tabular-nums">KF-000108</p>
                    <div className="flex items-center gap-1.5 mt-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-peacock-bright animate-pulse" />
                      <span className="text-[0.62rem] uppercase tracking-wide text-peacock-bright font-medium">
                        Confirmed
                      </span>
                    </div>
                  </div>
                  <div className="w-[72px] h-[72px] bg-moonlight rounded-lg shrink-0 shadow-lg">
                    <QRPlaceholder />
                  </div>
                </div>
              </div>
            </motion.div>
          </Reveal>

          {/* Description side */}
          <Reveal delay={0.2} className="max-w-md text-center lg:text-left">
            <p className="text-base sm:text-lg text-moonlight-silver font-light leading-relaxed">
              Each Krishna Pass is issued as a personal digital credential — not a
              printed ticket, not a generic QR on paper. Your name, your Journey ID,
              your access, sealed into one card.
            </p>
            <p className="mt-5 text-base sm:text-lg text-moonlight-silver font-light leading-relaxed">
              Present it once at the gate. From there, all nine doors open for you,
              and only you.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row lg:flex-col gap-3 items-center lg:items-start">
              <div className="flex items-center gap-2 text-moonlight-dim text-sm">
                <span className="w-1 h-1 rounded-full bg-gold-bright" />
                Non-transferable · Issued to one guest
              </div>
              <div className="flex items-center gap-2 text-moonlight-dim text-sm">
                <span className="w-1 h-1 rounded-full bg-gold-bright" />
                Delivered digitally within 24 hours of confirmation
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
