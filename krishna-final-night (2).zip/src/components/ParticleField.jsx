import { useMemo } from "react";

export default function ParticleField({ count = 36, className = "" }) {
  const particles = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        top: Math.random() * 100,
        size: Math.random() * 2 + 0.6,
        delay: Math.random() * 6,
        duration: Math.random() * 4 + 3,
      })),
    [count]
  );

  return (
    <div className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`} aria-hidden="true">
      {particles.map((p) => (
        <span
          key={p.id}
          className="absolute rounded-full bg-moonlight-silver"
          style={{
            left: `${p.left}%`,
            top: `${p.top}%`,
            width: `${p.size}px`,
            height: `${p.size}px`,
            animation: `twinkle ${p.duration}s ease-in-out ${p.delay}s infinite`,
            boxShadow: "0 0 6px rgba(217,189,126,0.6)",
          }}
        />
      ))}
    </div>
  );
}
