export default function PeacockFeather({ className = "", opacity = 1 }) {
  return (
    <svg
      viewBox="0 0 60 140"
      className={className}
      style={{ opacity }}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M30 140 C 30 100, 20 80, 12 55 C 4 30, 8 10, 30 2 C 52 10, 56 30, 48 55 C 40 80, 30 100, 30 140 Z"
        stroke="currentColor"
        strokeWidth="0.6"
        opacity="0.5"
      />
      <ellipse cx="30" cy="22" rx="13" ry="17" stroke="currentColor" strokeWidth="0.6" opacity="0.55" />
      <ellipse cx="30" cy="22" rx="8" ry="11" fill="currentColor" opacity="0.18" />
      <circle cx="30" cy="22" r="4.5" fill="currentColor" opacity="0.4" />
      <path d="M30 39 L30 130" stroke="currentColor" strokeWidth="0.5" opacity="0.4" />
      <path d="M30 50 C 20 55, 14 62, 10 72" stroke="currentColor" strokeWidth="0.4" opacity="0.3" />
      <path d="M30 50 C 40 55, 46 62, 50 72" stroke="currentColor" strokeWidth="0.4" opacity="0.3" />
      <path d="M30 70 C 18 76, 12 85, 8 96" stroke="currentColor" strokeWidth="0.4" opacity="0.25" />
      <path d="M30 70 C 42 76, 48 85, 52 96" stroke="currentColor" strokeWidth="0.4" opacity="0.25" />
      <path d="M30 92 C 20 98, 16 106, 14 116" stroke="currentColor" strokeWidth="0.4" opacity="0.2" />
      <path d="M30 92 C 40 98, 44 106, 46 116" stroke="currentColor" strokeWidth="0.4" opacity="0.2" />
    </svg>
  );
}
