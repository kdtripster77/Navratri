import { MapPin, Lock } from "lucide-react";
import Reveal from "./Reveal";
import Eyebrow from "./Eyebrow";
import ParticleField from "./ParticleField";

const atmosphere = [
  "Moonlit farm trails wrapped in white fabric tunnels",
  "Hundreds of hand-lit lamps lining the forest path",
  "Projection-mapped walls that breathe with the music",
  "An open-sky Maharaas ground beneath real stars",
];

export default function Venue() {
  return (
    <section className="relative py-28 sm:py-36 px-6 bg-void overflow-hidden">
      <div className="absolute inset-0 dot-grid opacity-25" />
      <div className="absolute top-0 right-0 w-[500px] h-[500px] glow-peacock rounded-full blur-3xl opacity-30" />
      <ParticleField count={24} />

      <div className="relative z-10 max-w-5xl mx-auto">
        <Reveal className="text-center mb-14">
          <Eyebrow color="silver">The Venue</Eyebrow>
          <h2 className="font-display font-light text-3xl sm:text-4xl md:text-5xl text-moonlight mt-6">
            A farm,
            <span className="italic text-gold-bright"> transformed.</span>
          </h2>
          <p className="mt-4 text-moonlight-dim font-light text-sm sm:text-base max-w-md mx-auto">
            Somewhere near Ahmedabad, a working farm becomes Vrindavan for one night.
          </p>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="relative rounded-3xl glass-strong overflow-hidden p-10 sm:p-14">
            <div className="absolute inset-0 bg-gradient-to-br from-peacock-deep/40 via-transparent to-void-deep/60" />
            <div className="relative z-10 grid sm:grid-cols-2 gap-10">
              <div>
                <h3 className="font-display text-2xl text-moonlight font-light mb-5">
                  What awaits, after dark
                </h3>
                <ul className="space-y-4">
                  {atmosphere.map((line) => (
                    <li key={line} className="flex items-start gap-3 text-moonlight-silver font-light text-[0.95rem]">
                      <span className="w-1.5 h-1.5 rounded-full bg-gold-bright mt-2 shrink-0" />
                      {line}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex flex-col justify-center items-start sm:items-end text-left sm:text-right">
                <div className="flex items-center gap-2 text-moonlight-dim mb-3">
                  <Lock size={14} strokeWidth={1.4} />
                  <span className="eyebrow text-[0.6rem]">Location Sealed</span>
                </div>
                <p className="text-moonlight-silver font-light text-base sm:text-lg leading-relaxed max-w-xs">
                  The exact location is revealed only after your pass is confirmed —
                  shared privately with each guest before the night.
                </p>
                <div className="flex items-center gap-2 mt-6 text-moonlight-dim">
                  <MapPin size={14} strokeWidth={1.4} />
                  <span className="text-sm">Near Ahmedabad, Gujarat</span>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
